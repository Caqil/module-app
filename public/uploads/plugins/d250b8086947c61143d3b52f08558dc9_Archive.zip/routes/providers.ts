import { OAuthUtils } from '../lib/oauth-utils';

export default async function handleProvidersRequest(context: any): Promise<Response> {
  const { request, method, database, user } = context;

  if (method === 'GET') {
    try {
      const pluginConfig = await database.Plugin.findOne({ 
        pluginId: 'oauth-plugin' 
      });
      
      if (!pluginConfig) {
        return new Response(JSON.stringify({
          success: false,
          error: 'OAuth plugin not configured'
        }), {
          status: 404,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // Build list of available providers
      const providers: any[] = [];
      const supportedProviders = ['google', 'github', 'facebook', 'linkedin'];
      
      supportedProviders.forEach(provider => {
        const config = pluginConfig.config[provider];
        if (config && config.enabled && config.clientId) {
          providers.push({
            id: provider,
            name: provider.charAt(0).toUpperCase() + provider.slice(1),
            icon: OAuthUtils.getProviderIcon(provider),
            color: OAuthUtils.getProviderColor(provider),
            loginUrl: `/api/plugin-routes/oauth/auth/${provider}`,
            enabled: true
          });
        }
      });

      return new Response(JSON.stringify({
        success: true,
        data: { 
          providers,
          total: providers.length
        }
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });

    } catch (error) {
      console.error('Failed to get OAuth providers:', error);
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to get providers'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }

  return new Response(JSON.stringify({
    success: false,
    error: 'Method not allowed'
  }), {
    status: 405,
    headers: { 'Content-Type': 'application/json' }
  });
}