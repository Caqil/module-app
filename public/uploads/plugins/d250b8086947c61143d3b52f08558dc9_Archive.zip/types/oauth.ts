export interface OAuthProvider {
  id: string;
  name: string;
  enabled: boolean;
  config: OAuthProviderConfig;
  authUrl?: string;
}

export interface OAuthProviderConfig {
  clientId: string;
  clientSecret: string;
  enabled: boolean;
  scope?: string;
  redirectUri?: string;
}

export interface OAuthUser {
  provider: string;
  providerId: string;
  email: string;
  name?: string;
  firstName?: string;
  lastName?: string;
  picture?: string;
  username?: string;
  raw: any;
}

export interface OAuthConnection {
  userId: string;
  provider: string;
  providerId: string;
  email: string;
  displayName?: string;
  profilePicture?: string;
  accessToken?: string;
  refreshToken?: string;
  createdAt: Date;
  lastUsed: Date;
}

export interface OAuthStats {
  totalOAuthUsers: number;
  todayLogins: number;
  providerBreakdown: Array<{
    _id: string;
    count: number;
    lastUsed: Date;
  }>;
  providers?: any;
}

export interface PluginContext {
  database: any;
  logger: any;
  config: Record<string, any>;
  api: {
    registerHook: (hook: any) => void;
  };
}

export interface OAuthProviderStats {
  total: number;
  enabled: number;
}

export interface DatabaseResult {
  success: boolean;
  error?: string;
  connectionId?: string;
}

export interface TokenResponse {
  access_token: string;
  refresh_token?: string;
  token_type: string;
  expires_in?: number;
  scope?: string;
}

export interface UserInfoResponse {
  id: string;
  email: string;
  name?: string;
  picture?: string;
  [key: string]: any;
}

export interface OAuthEvent {
  type: string;
  provider: string;
  email: string;
  timestamp: Date;
  ip?: string;
  userAgent?: string;
}