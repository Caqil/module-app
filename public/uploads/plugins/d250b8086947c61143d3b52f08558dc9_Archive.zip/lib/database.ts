import { OAuthConnection, OAuthStats, DatabaseResult } from '../types/oauth';

export class OAuthDatabase {
  private db: any;
  private collectionName: string = 'oauth_connections';
  private eventsCollectionName: string = 'oauth_events';

  constructor(database: any) {
    this.db = database;
  }

  async initialize(): Promise<DatabaseResult> {
    try {
      const collections = await this.db.connection.db.listCollections().toArray();
      
      // Create OAuth connections collection
      const hasOAuthCollection = collections.some((col: any) => col.name === this.collectionName);
      if (!hasOAuthCollection) {
        await this.db.connection.db.createCollection(this.collectionName);
        await this.db.connection.db.collection(this.collectionName).createIndexes([
          { key: { userId: 1 }, unique: false },
          { key: { provider: 1 }, unique: false },
          { key: { providerId: 1, provider: 1 }, unique: true },
          { key: { createdAt: 1 }, unique: false }
        ]);
      }

      // Create OAuth events collection
      const hasEventsCollection = collections.some((col: any) => col.name === this.eventsCollectionName);
      if (!hasEventsCollection) {
        await this.db.connection.db.createCollection(this.eventsCollectionName);
        await this.db.connection.db.collection(this.eventsCollectionName).createIndexes([
          { key: { timestamp: 1 }, unique: false },
          { key: { provider: 1 }, unique: false }
        ]);
      }

      return { success: true };
    } catch (error) {
      console.error('OAuth Database initialization failed:', error);
      return { success: false, error: (error as Error).message };
    }
  }

  async createOAuthConnection(data: Partial<OAuthConnection>): Promise<DatabaseResult> {
    try {
      const connection = {
        userId: data.userId,
        provider: data.provider,
        providerId: data.providerId,
        email: data.email,
        displayName: data.displayName,
        profilePicture: data.profilePicture,
        accessToken: data.accessToken,
        refreshToken: data.refreshToken,
        createdAt: new Date(),
        lastUsed: new Date()
      };

      const result = await this.db.connection.db.collection(this.collectionName).insertOne(connection);
      return { success: true, connectionId: result.insertedId };
    } catch (error) {
      console.error('Failed to create OAuth connection:', error);
      return { success: false, error: (error as Error).message };
    }
  }

  async updateOAuthConnection(userId: string, provider: string, updateData: Partial<OAuthConnection>): Promise<DatabaseResult> {
    try {
      const result = await this.db.connection.db.collection(this.collectionName).updateOne(
        { userId, provider },
        { 
          $set: {
            ...updateData,
            lastUsed: new Date()
          }
        }
      );

      return { success: result.modifiedCount > 0 };
    } catch (error) {
      console.error('Failed to update OAuth connection:', error);
      return { success: false, error: (error as Error).message };
    }
  }

  async getOAuthConnection(userId: string, provider: string): Promise<OAuthConnection | null> {
    try {
      const connection = await this.db.connection.db.collection(this.collectionName).findOne({
        userId,
        provider
      });
      return connection;
    } catch (error) {
      console.error('Failed to get OAuth connection:', error);
      return null;
    }
  }

  async getUserOAuthConnections(userId: string): Promise<OAuthConnection[]> {
    try {
      const connections = await this.db.connection.db.collection(this.collectionName)
        .find({ userId })
        .toArray();
      return connections;
    } catch (error) {
      console.error('Failed to get user OAuth connections:', error);
      return [];
    }
  }

  async getOAuthStats(): Promise<OAuthStats> {
    try {
      const pipeline = [
        {
          $group: {
            _id: '$provider',
            count: { $sum: 1 },
            lastUsed: { $max: '$lastUsed' }
          }
        },
        {
          $sort: { count: -1 }
        }
      ];

      const providerStats = await this.db.connection.db.collection(this.collectionName)
        .aggregate(pipeline)
        .toArray();

      const totalConnections = await this.db.connection.db.collection(this.collectionName)
        .countDocuments();

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const todayConnections = await this.db.connection.db.collection(this.collectionName)
        .countDocuments({
          lastUsed: { $gte: today }
        });

      return {
        totalOAuthUsers: totalConnections,
        todayLogins: todayConnections,
        providerBreakdown: providerStats
      };
    } catch (error) {
      console.error('Failed to get OAuth stats:', error);
      return {
        totalOAuthUsers: 0,
        todayLogins: 0,
        providerBreakdown: []
      };
    }
  }

  async updateOAuthConfig(config: Record<string, any>): Promise<DatabaseResult> {
    console.log('OAuth config updated:', Object.keys(config));
    return { success: true };
  }

  async removeOAuthConnection(userId: string, provider: string): Promise<DatabaseResult> {
    try {
      const result = await this.db.connection.db.collection(this.collectionName).deleteOne({
        userId,
        provider
      });
      return { success: result.deletedCount > 0 };
    } catch (error) {
      console.error('Failed to remove OAuth connection:', error);
      return { success: false, error: (error as Error).message };
    }
  }

  async logEvent(event: any): Promise<void> {
    try {
      await this.db.connection.db.collection(this.eventsCollectionName).insertOne(event);
    } catch (error) {
      console.error('Failed to log OAuth event:', error);
    }
  }

  async getUserById(userId: string): Promise<any> {
    try {
      return await this.db.User.findById(userId);
    } catch (error) {
      console.error('Failed to get user by ID:', error);
      return null;
    }
  }
}