class MinimalPlugin {
  constructor(context) {
    this.context = context;
  }

  async initialize() {
    console.log('Minimal Plugin: Initializing...');
    return { success: true };
  }

  async activate() {
    console.log('Minimal Plugin: Activating...');
    return { success: true };
  }

  async deactivate() {
    console.log('Minimal Plugin: Deactivating...');
    return { success: true };
  }
}

module.exports = MinimalPlugin;