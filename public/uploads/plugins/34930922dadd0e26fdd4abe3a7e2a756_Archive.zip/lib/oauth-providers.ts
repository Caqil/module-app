import { OAuthProvider, OAuthProviderConfig, OAuthProviderStats } from '../types/oauth';

export class OAuthProviders {
  private config: Record<string, any>;
  private providers: Record<string, OAuthProvider>;

  constructor(config: Record<string, any> = {}) {
    this.config = config;
    this.providers = {};
  }

  async initialize(): Promise<{ success: boolean; enabled?: number; total?: number; error?: string }> {
    try {
      const supportedProviders = ['google', 'github', 'facebook', 'linkedin'];
      let enabledCount = 0;

      for (const providerId of supportedProviders) {
        const providerConfig = this.config[providerId] as OAuthProviderConfig;
        if (providerConfig && providerConfig.enabled && providerConfig.clientId && providerConfig.clientSecret) {
          this.providers[providerId] = {
            id: providerId,
            name: providerId.charAt(0).toUpperCase() + providerId.slice(1),
            enabled: true,
            config: providerConfig,
            authUrl: this.buildAuthUrl(providerId, providerConfig)
          };
          enabledCount++;
        }
      }

      return { 
        success: true, 
        enabled: enabledCount,
        total: supportedProviders.length 
      };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  private buildAuthUrl(providerId: string, config: OAuthProviderConfig): string {
    const baseUrls: Record<string, string> = {
      google: 'https://accounts.google.com/o/oauth2/v2/auth',
      github: 'https://github.com/login/oauth/authorize',
      facebook: 'https://www.facebook.com/v18.0/dialog/oauth',
      linkedin: 'https://www.linkedin.com/oauth/v2/authorization'
    };

    const params = new URLSearchParams({
      client_id: config.clientId,
      redirect_uri: `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/plugin-routes/oauth/callback/${providerId}`,
      scope: this.getScope(providerId),
      response_type: 'code',
      state: this.generateState()
    });

    return `${baseUrls[providerId]}?${params.toString()}`;
  }

  private getScope(providerId: string): string {
    const scopes: Record<string, string> = {
      google: 'openid email profile',
      github: 'user:email',
      facebook: 'email',
      linkedin: 'r_liteprofile r_emailaddress'
    };
    return scopes[providerId] || 'email';
  }

  private generateState(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }

  getEnabledProviders(): OAuthProvider[] {
    return Object.values(this.providers).filter(p => p.enabled);
  }

  getProvider(providerId: string): OAuthProvider | null {
    return this.providers[providerId] || null;
  }

  getProviderStats(): OAuthProviderStats {
    const total = Object.keys(this.providers).length;
    const enabled = Object.values(this.providers).filter(p => p.enabled).length;
    return { total, enabled };
  }

  async updateConfig(newConfig: Record<string, any>): Promise<{ success: boolean; enabled?: number; total?: number; error?: string }> {
    this.config = newConfig;
    return this.initialize();
  }
}