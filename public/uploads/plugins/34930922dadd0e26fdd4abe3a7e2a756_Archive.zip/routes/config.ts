export default async function handleConfigRequest(context: any): Promise<Response> {
  const { request, method, database, user } = context;

  if (!user || user.role !== 'admin') {
    return new Response(JSON.stringify({
      success: false,
      error: 'Admin access required'
    }), {
      status: 403,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  if (method === 'GET') {
    try {
      const pluginConfig = await database.Plugin.findOne({ 
        pluginId: 'oauth-plugin' 
      });
      
      if (!pluginConfig) {
        return new Response(JSON.stringify({
          success: false,
          error: 'OAuth plugin not found'
        }), {
          status: 404,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // Remove sensitive data for display
      const sanitizedConfig = { ...pluginConfig.config };
      Object.keys(sanitizedConfig).forEach(provider => {
        if (sanitizedConfig[provider] && typeof sanitizedConfig[provider] === 'object') {
          Object.keys(sanitizedConfig[provider]).forEach(key => {
            if (key.includes('Secret') || key.includes('secret')) {
              sanitizedConfig[provider][key] = sanitizedConfig[provider][key] ? '••••••••' : '';
            }
          });
        }
      });

      return new Response(JSON.stringify({
        success: true,
        data: sanitizedConfig
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });

    } catch (error) {
      console.error('Failed to get OAuth config:', error);
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to get configuration'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }

  if (method === 'PUT') {
    try {
      const body = await request.json();
      const { config: newConfig } = body;

      if (!newConfig || typeof newConfig !== 'object') {
        return new Response(JSON.stringify({
          success: false,
          error: 'Invalid configuration data'
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // Get current config
      const currentPlugin = await database.Plugin.findOne({ 
        pluginId: 'oauth-plugin' 
      });

      if (!currentPlugin) {
        return new Response(JSON.stringify({
          success: false,
          error: 'OAuth plugin not found'
        }), {
          status: 404,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // Merge configurations, preserving existing secrets if not provided
      const mergedConfig = { ...currentPlugin.config };
      Object.keys(newConfig).forEach(provider => {
        if (newConfig[provider] && typeof newConfig[provider] === 'object') {
          mergedConfig[provider] = mergedConfig[provider] || {};
          Object.keys(newConfig[provider]).forEach(key => {
            if (key.includes('Secret') && newConfig[provider][key] === '••••••••') {
              // Keep existing secret
              return;
            }
            mergedConfig[provider][key] = newConfig[provider][key];
          });
        }
      });

      // Validate required fields for enabled providers
      const errors: string[] = [];
      Object.keys(mergedConfig).forEach(provider => {
        const providerConfig = mergedConfig[provider];
        if (providerConfig?.enabled) {
          if (!providerConfig.clientId) {
            errors.push(`${provider}: Client ID is required`);
          }
          if (!providerConfig.clientSecret) {
            errors.push(`${provider}: Client Secret is required`);
          }
        }
      });

      if (errors.length > 0) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Configuration validation failed',
          details: errors
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // Update plugin configuration
      await database.Plugin.updateOne(
        { pluginId: 'oauth-plugin' },
        { $set: { config: mergedConfig } }
      );

      return new Response(JSON.stringify({
        success: true,
        message: 'Configuration updated successfully'
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });

    } catch (error) {
      console.error('Failed to update OAuth config:', error);
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to update configuration'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }

  return new Response(JSON.stringify({
    success: false,
    error: 'Method not allowed'
  }), {
    status: 405,
    headers: { 'Content-Type': 'application/json' }
  });
}