const { OAuthProviders } = require('./lib/oauth-providers')
const { OAuthDatabase } = require('./lib/database')

class OAuthPlugin {
  constructor(context) {
    this.context = context
    this.config = context.config
    this.database = new OAuthDatabase(context.database)
    this.providers = new OAuthProviders(this.config)
  }

  async initialize() {
    console.log('🔐 OAuth Plugin: Initializing...')
    
    try {
      // Initialize database collections
      await this.database.initialize()
      
      // Initialize OAuth providers
      await this.providers.initialize()
      
      // Register hooks
      this.registerHooks()
      
      console.log('✅ OAuth Plugin: Successfully initialized')
      return { success: true }
    } catch (error) {
      console.error('❌ OAuth Plugin: Initialization failed:', error)
      return { success: false, error: error.message }
    }
  }

  registerHooks() {
    // Hook into authentication flow
    this.context.api.registerHook({
      name: 'auth:before-login',
      handler: this.handleBeforeLogin.bind(this),
      priority: 10
    })

    // Hook into user creation
    this.context.api.registerHook({
      name: 'user:before-create',
      handler: this.handleBeforeUserCreate.bind(this),
      priority: 10
    })
  }

  async handleBeforeLogin(data) {
    // Track OAuth login attempts
    if (data.provider) {
      await this.database.recordLoginAttempt(data.provider, data.email)
    }
    return data
  }

  async handleBeforeUserCreate(userData) {
    // Add OAuth-specific user data
    if (userData.oauthProvider) {
      userData.metadata = userData.metadata || {}
      userData.metadata.oauthProvider = userData.oauthProvider
      userData.metadata.oauthId = userData.oauthId
    }
    return userData
  }

  async getProviders() {
    return this.providers.getEnabledProviders()
  }

  async updateConfig(newConfig) {
    this.config = { ...this.config, ...newConfig }
    await this.providers.updateConfig(this.config)
    return { success: true }
  }

  async getStats() {
    return this.database.getOAuthStats()
  }

  async deactivate() {
    console.log('🔐 OAuth Plugin: Deactivating...')
    // Cleanup logic here
    return { success: true }
  }
}

module.exports = OAuthPlugin