import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Users,
  TrendingUp,
  Shield,
  AlertCircle,
  RefreshCw,
  LogIn,
  UserPlus,
  Activity,
} from "lucide-react";

interface OAuthStats {
  totalOAuthUsers: number;
  todayLogins: number;
  popularProvider: string;
  conversionRate: number;
  providerStats: Record<string, { users: number; enabled: boolean }>;
  recentActivity: Array<{
    type: string;
    provider: string;
    timestamp: Date;
    count: number;
  }>;
}

const OAuthStatsWidget: React.FC = () => {
  const [stats, setStats] = useState<OAuthStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  useEffect(() => {
    fetchStats();

    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchStats, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);

      // In a real implementation, this would fetch from your plugin's API
      // For now, we'll simulate realistic data
      const mockStats: OAuthStats = {
        totalOAuthUsers: 1247,
        todayLogins: 89,
        popularProvider: "Google",
        conversionRate: 78.5,
        providerStats: {
          google: { users: 789, enabled: true },
          github: { users: 312, enabled: true },
          facebook: { users: 146, enabled: false },
          linkedin: { users: 89, enabled: true },
        },
        recentActivity: [
          {
            type: "login",
            provider: "google",
            timestamp: new Date(Date.now() - 2 * 60 * 1000),
            count: 3,
          },
          {
            type: "signup",
            provider: "github",
            timestamp: new Date(Date.now() - 15 * 60 * 1000),
            count: 1,
          },
          {
            type: "login",
            provider: "linkedin",
            timestamp: new Date(Date.now() - 28 * 60 * 1000),
            count: 2,
          },
        ],
      };

      setStats(mockStats);
      setLastUpdated(new Date());
    } catch (error) {
      console.error("Failed to fetch OAuth stats:", error);
    } finally {
      setLoading(false);
    }
  };

  const getProviderIcon = (provider: string): string => {
    const icons: Record<string, string> = {
      google: "🔍",
      github: "🐱",
      facebook: "📘",
      linkedin: "💼",
    };
    return icons[provider] || "🔐";
  };

  const getProviderColor = (provider: string): string => {
    const colors: Record<string, string> = {
      google: "bg-blue-500",
      github: "bg-gray-800",
      facebook: "bg-blue-600",
      linkedin: "bg-blue-700",
    };
    return colors[provider] || "bg-gray-500";
  };

  const formatTimeAgo = (date: Date): string => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  if (loading && !stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            OAuth Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-4 bg-muted rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            OAuth Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 text-muted-foreground">
            <AlertCircle className="h-4 w-4" />
            <span>Unable to load OAuth statistics</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  const enabledProviders = Object.entries(stats.providerStats).filter(
    ([_, data]) => data.enabled
  );
  const totalProviderUsers = Object.values(stats.providerStats).reduce(
    (sum, data) => sum + data.users,
    0
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              OAuth Statistics
            </CardTitle>
            <CardDescription>
              Social login activity and provider performance
            </CardDescription>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={fetchStats}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="h-4 w-4 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold">
                {stats.totalOAuthUsers.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">OAuth Users</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <LogIn className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold">{stats.todayLogins}</div>
              <div className="text-sm text-muted-foreground">
                Today's Logins
              </div>
            </div>
          </div>
        </div>

        {/* Provider Breakdown */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Active Providers</span>
            <Badge variant="secondary">{enabledProviders.length}</Badge>
          </div>

          <div className="space-y-2">
            {enabledProviders.map(([provider, data]) => {
              const percentage =
                totalProviderUsers > 0
                  ? Math.round((data.users / totalProviderUsers) * 100)
                  : 0;

              return (
                <div
                  key={provider}
                  className="flex items-center justify-between p-2 rounded-lg bg-muted/50"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`p-1 rounded text-white text-xs ${getProviderColor(provider)}`}
                    >
                      {getProviderIcon(provider)}
                    </div>
                    <span className="text-sm font-medium capitalize">
                      {provider}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {data.users}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {percentage}%
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Popular Provider */}
        {stats.popularProvider && (
          <div className="border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium">Most Popular</span>
                <div className="text-lg font-semibold">
                  {stats.popularProvider}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium">
                  {stats.conversionRate}%
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Recent Activity */}
        <div className="border-t pt-4">
          <div className="flex items-center gap-2 mb-3">
            <Activity className="h-4 w-4" />
            <span className="text-sm font-medium">Recent Activity</span>
          </div>

          <div className="space-y-2">
            {stats.recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between text-sm"
              >
                <div className="flex items-center gap-2">
                  {activity.type === "login" ? (
                    <LogIn className="h-3 w-3 text-blue-600" />
                  ) : (
                    <UserPlus className="h-3 w-3 text-green-600" />
                  )}
                  <span className="capitalize">{activity.type}</span>
                  <span className="text-muted-foreground">
                    via {activity.provider}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {activity.count}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {formatTimeAgo(activity.timestamp)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Last Updated */}
        <div className="border-t pt-3">
          <div className="text-xs text-muted-foreground text-center">
            Last updated: {lastUpdated.toLocaleTimeString()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default OAuthStatsWidget;
