import { OAuthProviders } from './lib/oauth-providers';
import { OAuthDatabase } from './lib/database';
import { OAuthUtils } from './lib/oauth-utils';
import { PluginContext, OAuthProviderStats, OAuthStats } from './types/oauth';

export class OAuthPlugin {
  private context: PluginContext;
  private config: Record<string, any>;
  private database: OAuthDatabase;
  private providers: OAuthProviders;

  constructor(context: PluginContext) {
    this.context = context;
    this.config = context.config;
    this.database = new OAuthDatabase(context.database);
    this.providers = new OAuthProviders(this.config);
  }

  async initialize(): Promise<{ success: boolean; providersEnabled?: number; providersTotal?: number; error?: string }> {
    console.log('🔐 OAuth Plugin: Initializing...');
    
    try {
      // Initialize database collections and indexes
      await this.database.initialize();
      
      // Initialize OAuth providers
      const providersResult = await this.providers.initialize();
      if (!providersResult.success) {
        console.warn('⚠️ OAuth Plugin: Provider initialization issues:', providersResult.error);
      }
      
      // Register hooks
      this.registerHooks();
      
      // Log initialization summary
      const stats = this.providers.getProviderStats();
      console.log(`✅ OAuth Plugin: Successfully initialized with ${stats.enabled}/${stats.total} providers active`);
      
      return { 
        success: true, 
        providersEnabled: stats.enabled,
        providersTotal: stats.total
      };
    } catch (error) {
      console.error('❌ OAuth Plugin: Initialization failed:', error);
      return { success: false, error: (error as Error).message };
    }
  }

  private registerHooks(): void {
    // Hook into authentication flow
    this.context.api.registerHook({
      name: 'auth:before-login',
      handler: this.handleBeforeLogin.bind(this),
      priority: 10
    });

    // Hook into user creation
    this.context.api.registerHook({
      name: 'user:before-create',
      handler: this.handleBeforeUserCreate.bind(this),
      priority: 10
    });

    // Hook into user profile updates
    this.context.api.registerHook({
      name: 'user:before-update',
      handler: this.handleBeforeUserUpdate.bind(this),
      priority: 10
    });
  }

  private async handleBeforeLogin(data: any): Promise<any> {
    if (data.provider) {
      await OAuthUtils.logOAuthEvent('login_attempt', data.provider, data.email, this.database);
    }
    return data;
  }

  private async handleBeforeUserCreate(userData: any): Promise<any> {
    if (userData.provider) {
      userData.metadata = userData.metadata || {};
      userData.metadata.primaryProvider = userData.provider;
      userData.metadata.providerId = userData.providerId;
      userData.metadata.oauthCreatedAt = new Date();
    }
    return userData;
  }

  private async handleBeforeUserUpdate(userData: any): Promise<any> {
    if (userData.metadata?.primaryProvider) {
      userData.metadata.oauthUpdatedAt = new Date();
    }
    return userData;
  }

  async getProviders(): Promise<any[]> {
    return this.providers.getEnabledProviders();
  }

  async getProviderStats(): Promise<OAuthProviderStats> {
    return this.providers.getProviderStats();
  }

  async updateConfig(newConfig: Record<string, any>): Promise<{ success: boolean }> {
    this.config = { ...this.config, ...newConfig };
    await this.providers.updateConfig(this.config);
    await this.database.updateOAuthConfig(this.config);
    console.log('🔐 OAuth Plugin: Configuration updated');
    return { success: true };
  }

  async getStats(): Promise<OAuthStats | null> {
    try {
      const [dbStats, providerStats] = await Promise.all([
        this.database.getOAuthStats(),
        this.providers.getProviderStats()
      ]);

      return {
        ...dbStats,
        providers: providerStats
      } as OAuthStats;
    } catch (error) {
      console.error('Failed to get OAuth stats:', error);
      return null;
    }
  }

  async testProvider(providerId: string): Promise<{ success: boolean; error?: string; message?: string; authUrl?: string }> {
    try {
      const provider = this.providers.getProvider(providerId);
      if (!provider) {
        return { success: false, error: 'Provider not found' };
      }

      const authUrl = provider.authUrl;
      if (!authUrl) {
        return { success: false, error: 'Failed to build auth URL' };
      }

      return { 
        success: true, 
        message: 'Provider configuration is valid',
        authUrl: authUrl.substring(0, 100) + '...'
      };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  async getProviderHealth(): Promise<Record<string, any>> {
    const health: Record<string, any> = {};
    const enabledProviders = this.providers.getEnabledProviders();

    for (const provider of enabledProviders) {
      const test = await this.testProvider(provider.id);
      health[provider.id] = {
        name: provider.name,
        enabled: true,
        healthy: test.success,
        error: test.error || null
      };
    }

    return health;
  }

  async deactivate(): Promise<{ success: boolean; error?: string }> {
    console.log('🔐 OAuth Plugin: Deactivating...');
    
    try {
      console.log('✅ OAuth Plugin: Successfully deactivated');
      return { success: true };
    } catch (error) {
      console.error('❌ OAuth Plugin: Deactivation failed:', error);
      return { success: false, error: (error as Error).message };
    }
  }

  async isUserOAuthEnabled(userId: string): Promise<boolean> {
    try {
      const connections = await this.database.getUserOAuthConnections(userId);
      return connections.length > 0;
    } catch {
      return false;
    }
  }

  async getUserProviders(userId: string): Promise<string[]> {
    try {
      const connections = await this.database.getUserOAuthConnections(userId);
      return connections.map(conn => conn.provider);
    } catch (error) {
      console.error('Failed to get user providers:', error);
      return [];
    }
  }
}

export default OAuthPlugin;