export default async function handleAuthRequest(context: any): Promise<Response> {
  const { request, method, path, database } = context;
  const provider = path.split('/').pop();

  if (method !== 'GET') {
    return new Response(JSON.stringify({
      success: false,
      error: 'Method not allowed'
    }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    // Get plugin configuration
    const pluginConfig = await database.Plugin.findOne({ 
      pluginId: 'oauth-plugin' 
    });
    
    if (!pluginConfig || !pluginConfig.config[provider]?.enabled) {
      return new Response(JSON.stringify({
        success: false,
        error: 'OAuth provider not enabled'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const config = pluginConfig.config[provider];
    
    // Build auth URL
    const baseUrls: Record<string, string> = {
      google: 'https://accounts.google.com/o/oauth2/v2/auth',
      github: 'https://github.com/login/oauth/authorize',
      facebook: 'https://www.facebook.com/v18.0/dialog/oauth',
      linkedin: 'https://www.linkedin.com/oauth/v2/authorization'
    };

    const scopes: Record<string, string> = {
      google: 'openid email profile',
      github: 'user:email',
      facebook: 'email',
      linkedin: 'r_liteprofile r_emailaddress'
    };

    const params = new URLSearchParams({
      client_id: config.clientId,
      redirect_uri: `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/plugin-routes/oauth/callback/${provider}`,
      scope: scopes[provider] || 'email',
      response_type: 'code',
      state: Math.random().toString(36).substring(2, 15)
    });

    const authUrl = `${baseUrls[provider]}?${params.toString()}`;

    // Redirect to OAuth provider
    return new Response(null, {
      status: 302,
      headers: {
        'Location': authUrl
      }
    });

  } catch (error) {
    console.error('OAuth auth error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: 'Failed to initiate OAuth authentication'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}