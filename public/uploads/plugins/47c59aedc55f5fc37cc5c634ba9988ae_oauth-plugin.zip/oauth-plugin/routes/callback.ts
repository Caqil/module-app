import { OAuthUtils } from '../lib/oauth-utils';

export default async function handleOAuthCallback(context: any): Promise<Response> {
  const { request, method, path, user, database, utils } = context;
  const url = new URL(request.url);
  const provider = path.split('/').pop();
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const error = url.searchParams.get('error');

  try {
    if (error) {
      console.error(`OAuth ${provider} error:`, error);
      return new Response(JSON.stringify({
        success: false,
        error: 'OAuth authentication failed'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (!code) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Authorization code not provided'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Get plugin configuration
    const pluginConfig = await database.Plugin.findOne({ 
      pluginId: 'oauth-plugin' 
    });
    
    if (!pluginConfig || !pluginConfig.config[provider]?.enabled) {
      return new Response(JSON.stringify({
        success: false,
        error: 'OAuth provider not enabled'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Exchange code for access token
    const tokenData = await OAuthUtils.exchangeCodeForToken(provider, code, pluginConfig.config[provider]);
    
    if (!tokenData.access_token) {
      throw new Error('Failed to get access token');
    }

    // Get user info from OAuth provider
    const oauthUser = await OAuthUtils.getUserInfo(provider, tokenData.access_token);
    
    if (!oauthUser.email) {
      throw new Error('Email not provided by OAuth provider');
    }

    // Check if user exists
    let existingUser = await database.User.findOne({ email: oauthUser.email });
    
    if (existingUser) {
      // Update existing user with OAuth info
      if (!existingUser.metadata) existingUser.metadata = {};
      existingUser.metadata.oauthProviders = existingUser.metadata.oauthProviders || [];
      
      if (!existingUser.metadata.oauthProviders.includes(provider)) {
        existingUser.metadata.oauthProviders.push(provider);
        await existingUser.save();
      }

      // Create OAuth connection
      const oauthDatabase = await import('../lib/database');
      const db = new oauthDatabase.OAuthDatabase(database);
      
      await db.createOAuthConnection({
        userId: existingUser._id.toString(),
        provider: provider,
        providerId: oauthUser.providerId,
        email: oauthUser.email,
        displayName: oauthUser.name,
        profilePicture: oauthUser.picture,
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token
      });

      // Log successful login
      await OAuthUtils.logOAuthEvent('login_success', provider, oauthUser.email, db);

      // Redirect to success page
      return new Response(null, {
        status: 302,
        headers: {
          'Location': '/dashboard?oauth=success'
        }
      });

    } else {
      // Create new user
      const newUser = await database.User.create({
        email: oauthUser.email,
        firstName: oauthUser.firstName || oauthUser.name?.split(' ')[0] || 'Unknown',
        lastName: oauthUser.lastName || oauthUser.name?.split(' ').slice(1).join(' ') || '',
        isEmailVerified: true,
        metadata: {
          primaryProvider: provider,
          oauthProviders: [provider],
          providerId: oauthUser.providerId,
          profilePicture: oauthUser.picture
        }
      });

      // Create OAuth connection
      const oauthDatabase = await import('../lib/database');
      const db = new oauthDatabase.OAuthDatabase(database);
      
      await db.createOAuthConnection({
        userId: newUser._id.toString(),
        provider: provider,
        providerId: oauthUser.providerId,
        email: oauthUser.email,
        displayName: oauthUser.name,
        profilePicture: oauthUser.picture,
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token
      });

      // Log successful registration
      await OAuthUtils.logOAuthEvent('registration_success', provider, oauthUser.email, db);

      // Redirect to welcome page
      return new Response(null, {
        status: 302,
        headers: {
          'Location': '/welcome?oauth=success&new=true'
        }
      });
    }

  } catch (error) {
    console.error('OAuth callback error:', error);
    
    // Log failed attempt
    try {
      const oauthDatabase = await import('../lib/database');
      const db = new oauthDatabase.OAuthDatabase(database);
      await OAuthUtils.logOAuthEvent('login_failed', provider, 'unknown', db);
    } catch (logError) {
      console.error('Failed to log OAuth error:', logError);
    }

    return new Response(JSON.stringify({
      success: false,
      error: 'OAuth authentication failed'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}