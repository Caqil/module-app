import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Loader2,
  Save,
  Eye,
  EyeOff,
  Shield,
  ExternalLink,
  TestTube,
} from "lucide-react";

interface ProviderConfig {
  enabled: boolean;
  clientId: string;
  clientSecret: string;
}

interface OAuthConfig {
  [key: string]: ProviderConfig;
}

const OAuthSettings: React.FC = () => {
  const [config, setConfig] = useState<OAuthConfig>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});

  const providers = [
    {
      id: "google",
      name: "Google",
      description: "Enable Google OAuth login",
      docsUrl: "https://console.developers.google.com/",
      icon: "🔍",
      color: "bg-blue-500",
    },
    {
      id: "github",
      name: "GitHub",
      description: "Enable GitHub OAuth login",
      docsUrl: "https://github.com/settings/applications/new",
      icon: "🐱",
      color: "bg-gray-800",
    },
    {
      id: "facebook",
      name: "Facebook",
      description: "Enable Facebook OAuth login",
      docsUrl: "https://developers.facebook.com/",
      icon: "📘",
      color: "bg-blue-600",
    },
    {
      id: "linkedin",
      name: "LinkedIn",
      description: "Enable LinkedIn OAuth login",
      docsUrl: "https://www.linkedin.com/developers/",
      icon: "💼",
      color: "bg-blue-700",
    },
  ];

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/plugin-routes/oauth/config", {
        credentials: "include",
      });

      const result = await response.json();

      if (result.success) {
        setConfig(result.data || {});
      } else {
        setError(result.error || "Failed to load configuration");
      }
    } catch (err) {
      setError("Network error occurred");
    } finally {
      setLoading(false);
    }
  };

  const saveConfig = async () => {
    try {
      setSaving(true);
      setError("");
      setSuccess("");

      const response = await fetch("/api/plugin-routes/oauth/config", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ config }),
      });

      const result = await response.json();

      if (result.success) {
        setSuccess("Configuration saved successfully");
        setTimeout(() => setSuccess(""), 3000);
      } else {
        setError(result.error || "Failed to save configuration");
      }
    } catch (err) {
      setError("Network error occurred");
    } finally {
      setSaving(false);
    }
  };

  const testProvider = async (providerId: string) => {
    try {
      setTesting(providerId);

      // Simulate provider test
      const response = await fetch(
        `/api/plugin-routes/oauth/test/${providerId}`,
        {
          credentials: "include",
        }
      );

      const result = await response.json();

      if (result.success) {
        setSuccess(`${providerId} provider configuration is valid`);
        setTimeout(() => setSuccess(""), 3000);
      } else {
        setError(result.error || `Failed to test ${providerId} provider`);
      }
    } catch (err) {
      setError(`Test failed for ${providerId}`);
    } finally {
      setTesting(null);
    }
  };

  const updateProviderConfig = (
    providerId: string,
    field: keyof ProviderConfig,
    value: any
  ) => {
    setConfig((prev) => ({
      ...prev,
      [providerId]: {
        ...prev[providerId],
        [field]: value,
      },
    }));
  };

  const toggleSecretVisibility = (providerId: string) => {
    setShowSecrets((prev) => ({
      ...prev,
      [providerId]: !prev[providerId],
    }));
  };

  const getEnabledCount = () => {
    return Object.values(config).filter((provider) => provider?.enabled).length;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">OAuth Provider Settings</h1>
          <p className="text-muted-foreground">
            Configure OAuth providers to enable social login for your users.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            {getEnabledCount()} of {providers.length} enabled
          </Badge>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="providers" className="space-y-6">
        <TabsList>
          <TabsTrigger value="providers">Provider Configuration</TabsTrigger>
          <TabsTrigger value="settings">Advanced Settings</TabsTrigger>
          <TabsTrigger value="logs">Activity Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="providers" className="space-y-6">
          <div className="grid gap-6">
            {providers.map((provider) => {
              const providerConfig = config[provider.id] || {
                enabled: false,
                clientId: "",
                clientSecret: "",
              };

              return (
                <Card key={provider.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div
                          className={`p-3 rounded-lg ${provider.color} text-white text-xl`}
                        >
                          {provider.icon}
                        </div>
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {provider.name}
                            <Switch
                              checked={providerConfig.enabled || false}
                              onCheckedChange={(enabled) =>
                                updateProviderConfig(
                                  provider.id,
                                  "enabled",
                                  enabled
                                )
                              }
                            />
                          </CardTitle>
                          <CardDescription>
                            {provider.description}
                          </CardDescription>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {providerConfig.enabled && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => testProvider(provider.id)}
                            disabled={testing === provider.id}
                          >
                            {testing === provider.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <TestTube className="h-4 w-4" />
                            )}
                            Test
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() =>
                            window.open(provider.docsUrl, "_blank")
                          }
                        >
                          <ExternalLink className="h-4 w-4" />
                          Setup Guide
                        </Button>
                      </div>
                    </div>
                  </CardHeader>

                  {providerConfig.enabled && (
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Client ID</Label>
                          <Input
                            value={providerConfig.clientId || ""}
                            onChange={(e) =>
                              updateProviderConfig(
                                provider.id,
                                "clientId",
                                e.target.value
                              )
                            }
                            placeholder="Enter client ID"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Client Secret</Label>
                          <div className="relative">
                            <Input
                              type={
                                showSecrets[provider.id] ? "text" : "password"
                              }
                              value={providerConfig.clientSecret || ""}
                              onChange={(e) =>
                                updateProviderConfig(
                                  provider.id,
                                  "clientSecret",
                                  e.target.value
                                )
                              }
                              placeholder="Enter client secret"
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="absolute right-0 top-0 h-full px-3"
                              onClick={() =>
                                toggleSecretVisibility(provider.id)
                              }
                            >
                              {showSecrets[provider.id] ? (
                                <EyeOff className="h-4 w-4" />
                              ) : (
                                <Eye className="h-4 w-4" />
                              )}
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="bg-muted p-3 rounded text-sm">
                        <p className="font-medium mb-1">Callback URL:</p>
                        <code className="text-xs break-all">
                          {window.location.origin}
                          /api/plugin-routes/oauth/callback/{provider.id}
                        </code>
                      </div>

                      {providerConfig.enabled &&
                        providerConfig.clientId &&
                        providerConfig.clientSecret && (
                          <div className="bg-green-50 p-3 rounded border border-green-200">
                            <p className="text-green-800 text-sm flex items-center gap-2">
                              <Shield className="h-4 w-4" />
                              Provider configured and ready
                            </p>
                          </div>
                        )}
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Advanced OAuth Settings</CardTitle>
              <CardDescription>
                Configure advanced OAuth behavior and security settings.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-muted-foreground">
                Advanced settings will be available in future updates.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>OAuth Activity Logs</CardTitle>
              <CardDescription>
                Monitor OAuth authentication activity and troubleshoot issues.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-muted-foreground">
                Activity logs will be available in future updates.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={saveConfig} disabled={saving} size="lg">
          {saving && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
          <Save className="h-4 w-4 mr-2" />
          Save Configuration
        </Button>
      </div>
    </div>
  );
};

export default OAuthSettings;
