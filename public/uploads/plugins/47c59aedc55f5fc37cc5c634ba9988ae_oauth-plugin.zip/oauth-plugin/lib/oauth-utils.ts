import { OAuthUser, TokenResponse, UserInfoResponse, OAuthEvent } from '../types/oauth';
import { OAuthDatabase } from './database';

export class OAuthUtils {
  static async logOAuthEvent(
    eventType: string, 
    provider: string, 
    email: string, 
    database: OAuthDatabase,
    additionalData: any = {}
  ): Promise<void> {
    try {
      const event: OAuthEvent = {
        type: eventType,
        provider,
        email,
        timestamp: new Date(),
        ip: additionalData.ip || 'unknown',
        userAgent: additionalData.userAgent || 'unknown'
      };

      await database.logEvent(event);
      console.log(`OAuth Event: ${eventType} via ${provider} for ${email}`);
    } catch (error) {
      console.error('Failed to log OAuth event:', error);
    }
  }

  static generateState(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }

  static validateState(providedState: string, expectedState: string): boolean {
    return providedState === expectedState;
  }

  static sanitizeOAuthData(data: any): any {
    const sanitized = { ...data };
    delete sanitized.accessToken;
    delete sanitized.refreshToken;
    delete sanitized.clientSecret;
    return sanitized;
  }

  static async exchangeCodeForToken(provider: string, code: string, config: any): Promise<TokenResponse> {
    const tokenUrls: Record<string, string> = {
      google: 'https://oauth2.googleapis.com/token',
      github: 'https://github.com/login/oauth/access_token',
      facebook: 'https://graph.facebook.com/v18.0/oauth/access_token',
      linkedin: 'https://www.linkedin.com/oauth/v2/accessToken'
    };

    const tokenData = {
      client_id: config.clientId,
      client_secret: config.clientSecret,
      code: code,
      grant_type: 'authorization_code',
      redirect_uri: `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/plugin-routes/oauth/callback/${provider}`
    };

    try {
      const response = await fetch(tokenUrls[provider], {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        },
        body: new URLSearchParams(tokenData).toString()
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(`Token exchange failed: ${result.error_description || result.error}`);
      }

      return result;
    } catch (error) {
      console.error(`Token exchange failed for ${provider}:`, error);
      throw error;
    }
  }

  static async getUserInfo(provider: string, accessToken: string): Promise<OAuthUser> {
    const userInfoUrls: Record<string, string> = {
      google: 'https://www.googleapis.com/oauth2/v2/userinfo',
      github: 'https://api.github.com/user',
      facebook: 'https://graph.facebook.com/me?fields=id,name,email,picture',
      linkedin: 'https://api.linkedin.com/v2/people/~:(id,firstName,lastName,emailAddress)'
    };

    try {
      const response = await fetch(userInfoUrls[provider], {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`User info request failed: ${response.statusText}`);
      }

      const userData = await response.json();
      return this.normalizeUserData(provider, userData);
    } catch (error) {
      console.error(`User info request failed for ${provider}:`, error);
      throw error;
    }
  }

  static normalizeUserData(provider: string, rawData: any): OAuthUser {
    const normalized: OAuthUser = {
      provider,
      providerId: rawData.id || rawData.sub,
      email: rawData.email,
      name: rawData.name,
      picture: rawData.picture || rawData.avatar_url,
      raw: rawData
    };

    switch (provider) {
      case 'google':
        normalized.name = rawData.name;
        normalized.firstName = rawData.given_name;
        normalized.lastName = rawData.family_name;
        break;
        
      case 'github':
        normalized.name = rawData.name || rawData.login;
        normalized.username = rawData.login;
        break;
        
      case 'facebook':
        normalized.name = rawData.name;
        normalized.picture = rawData.picture?.data?.url;
        break;
        
      case 'linkedin':
        const firstName = rawData.firstName?.localized?.en_US;
        const lastName = rawData.lastName?.localized?.en_US;
        normalized.name = `${firstName} ${lastName}`.trim();
        normalized.firstName = firstName;
        normalized.lastName = lastName;
        break;
    }

    return normalized;
  }

  static getProviderIcon(provider: string): string {
    const icons: Record<string, string> = {
      google: '🔍',
      github: '🐱',
      facebook: '📘',
      linkedin: '💼'
    };
    return icons[provider] || '🔐';
  }

  static getProviderColor(provider: string): string {
    const colors: Record<string, string> = {
      google: '#4285f4',
      github: '#333',
      facebook: '#1877f2',
      linkedin: '#0077b5'
    };
    return colors[provider] || '#6b7280';
  }
}