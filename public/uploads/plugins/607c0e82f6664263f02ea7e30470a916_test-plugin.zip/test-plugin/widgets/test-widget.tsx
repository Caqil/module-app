import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TestTube, RefreshCw, CheckCircle, XCircle, Clock } from "lucide-react";

const TestWidget: React.FC = () => {
  const [status, setStatus] = useState<{
    active: boolean;
    message: string;
    timestamp: string;
    lastTest?: {
      success: boolean;
      timestamp: string;
    };
  }>({
    active: true,
    message: "Hello from Test Plugin!",
    timestamp: new Date().toISOString(),
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    updateStatus();

    // Auto-refresh every 30 seconds
    const interval = setInterval(updateStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const updateStatus = async () => {
    try {
      // Simulate getting plugin status
      const newStatus = {
        active: true,
        message: "Hello from Test Plugin!",
        timestamp: new Date().toISOString(),
        lastTest: status.lastTest,
      };

      setStatus(newStatus);
    } catch (error) {
      console.error("Failed to update test widget status:", error);
    }
  };

  const runQuickTest = async () => {
    try {
      setLoading(true);

      const response = await fetch("/api/plugin-routes/test/hello", {
        credentials: "include",
      });

      const result = await response.json();

      setStatus((prev) => ({
        ...prev,
        lastTest: {
          success: result.success,
          timestamp: new Date().toISOString(),
        },
      }));
    } catch (error) {
      setStatus((prev) => ({
        ...prev,
        lastTest: {
          success: false,
          timestamp: new Date().toISOString(),
        },
      }));
    } finally {
      setLoading(false);
    }
  };

  const formatTimeAgo = (timestamp: string): string => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMs = now.getTime() - time.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <TestTube className="h-5 w-5" />
              Test Plugin
            </CardTitle>
            <CardDescription>Plugin system test widget</CardDescription>
          </div>
          <Badge variant={status.active ? "default" : "secondary"}>
            {status.active ? "Active" : "Inactive"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Plugin Message */}
        <div className="p-3 bg-muted/50 rounded-lg">
          <div className="text-sm font-medium mb-1">Current Message:</div>
          <div className="text-sm text-muted-foreground">
            "{status.message}"
          </div>
        </div>

        {/* Last Test Result */}
        {status.lastTest && (
          <div className="flex items-center justify-between p-3 border rounded-lg">
            <div className="flex items-center gap-2">
              {status.lastTest.success ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              <span className="text-sm font-medium">
                Last Test: {status.lastTest.success ? "Passed" : "Failed"}
              </span>
            </div>
            <span className="text-xs text-muted-foreground">
              {formatTimeAgo(status.lastTest.timestamp)}
            </span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={runQuickTest}
            disabled={loading}
            className="flex-1"
          >
            {loading ? (
              <RefreshCw className="h-3 w-3 animate-spin mr-1" />
            ) : (
              <TestTube className="h-3 w-3 mr-1" />
            )}
            Quick Test
          </Button>

          <Button variant="ghost" size="sm" onClick={updateStatus}>
            <RefreshCw className="h-3 w-3" />
          </Button>
        </div>

        {/* Status Info */}
        <div className="border-t pt-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            Updated: {formatTimeAgo(status.timestamp)}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TestWidget;
