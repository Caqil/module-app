async function handleHelloRequest(context) {
  const { request, method, user, database } = context;

  if (method !== 'GET') {
    return new Response(JSON.stringify({
      success: false,
      error: 'Method not allowed'
    }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    // Get plugin configuration
    const pluginConfig = await database.Plugin.findOne({ 
      pluginId: 'test-plugin' 
    });

    const message = pluginConfig?.config?.message || 'Hello from Test Plugin!';
    const enabled = pluginConfig?.config?.enabled !== false;

    return new Response(JSON.stringify({
      success: true,
      data: {
        message: message,
        enabled: enabled,
        timestamp: new Date().toISOString(),
        user: user ? {
          id: user.id,
          email: user.email,
          role: user.role
        } : null,
        pluginInfo: {
          id: 'test-plugin',
          name: 'Test Plugin',
          version: '1.0.0'
        }
      }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Test Plugin: Hello route error:', error);
    
    return new Response(JSON.stringify({
      success: false,
      error: 'Internal server error',
      message: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

module.exports = handleHelloRequest;