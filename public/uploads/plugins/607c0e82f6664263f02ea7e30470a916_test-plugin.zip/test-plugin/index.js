class TestPlugin {
  constructor(context) {
    this.context = context;
    this.config = context.config || {};
  }

  async initialize() {
    console.log('🧪 Test Plugin: Initializing...');
    
    try {
      // Simple initialization
      const message = this.config.message || 'Hello from Test Plugin!';
      console.log(`✅ Test Plugin: ${message}`);
      
      return { 
        success: true,
        message: 'Test Plugin initialized successfully'
      };
    } catch (error) {
      console.error('❌ Test Plugin: Initialization failed:', error);
      return { 
        success: false, 
        error: error.message 
      };
    }
  }

  async activate() {
    console.log('🧪 Test Plugin: Activating...');
    return { 
      success: true,
      message: 'Test Plugin activated successfully'
    };
  }

  async deactivate() {
    console.log('🧪 Test Plugin: Deactivating...');
    return { 
      success: true,
      message: 'Test Plugin deactivated successfully'
    };
  }

  getStatus() {
    return {
      active: this.config.enabled !== false,
      message: this.config.message || 'Hello from Test Plugin!',
      timestamp: new Date().toISOString()
    };
  }

  async updateConfig(newConfig) {
    this.config = { ...this.config, ...newConfig };
    console.log('🧪 Test Plugin: Configuration updated', this.config);
    return { success: true };
  }
}

module.exports = TestPlugin;