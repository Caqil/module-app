import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Loader2, Save, TestTube, RefreshCw } from "lucide-react";

const TestSettings: React.FC = () => {
  const [config, setConfig] = useState({
    message: "Hello from Test Plugin!",
    enabled: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      setLoading(true);
      setError("");

      // In a real plugin, this would load from the plugin configuration API
      // For this test, we'll simulate loading configuration
      setTimeout(() => {
        setConfig({
          message: "Hello from Test Plugin!",
          enabled: true,
        });
        setLoading(false);
      }, 500);
    } catch (err) {
      setError("Failed to load configuration");
      setLoading(false);
    }
  };

  const saveConfig = async () => {
    try {
      setSaving(true);
      setError("");
      setSuccess("");

      // Simulate saving configuration
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setSuccess("Configuration saved successfully!");
      setTimeout(() => setSuccess(""), 3000);
    } catch (err) {
      setError("Failed to save configuration");
    } finally {
      setSaving(false);
    }
  };

  const testPlugin = async () => {
    try {
      setTesting(true);
      setTestResult(null);
      setError("");

      // Test the plugin's hello endpoint
      const response = await fetch("/api/plugin-routes/test/hello", {
        credentials: "include",
      });

      const result = await response.json();
      setTestResult(result);

      if (result.success) {
        setSuccess("Plugin test successful!");
        setTimeout(() => setSuccess(""), 3000);
      } else {
        setError(`Test failed: ${result.error}`);
      }
    } catch (err) {
      setError("Failed to test plugin");
      setTestResult({ success: false, error: "Network error" });
    } finally {
      setTesting(false);
    }
  };

  const updateConfig = (field: string, value: any) => {
    setConfig((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Test Plugin Settings</h1>
          <p className="text-muted-foreground">
            Configure and test the test plugin functionality.
          </p>
        </div>
        <Badge variant="outline" className="flex items-center gap-2">
          <TestTube className="h-4 w-4" />
          Test Plugin v1.0.0
        </Badge>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-6">
        {/* Configuration Card */}
        <Card>
          <CardHeader>
            <CardTitle>Plugin Configuration</CardTitle>
            <CardDescription>
              Configure the basic settings for the test plugin.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label htmlFor="enabled">Enable Plugin</Label>
                <p className="text-sm text-muted-foreground">
                  Turn the plugin functionality on or off
                </p>
              </div>
              <Switch
                id="enabled"
                checked={config.enabled}
                onCheckedChange={(enabled) => updateConfig("enabled", enabled)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="message">Plugin Message</Label>
              <Input
                id="message"
                value={config.message}
                onChange={(e) => updateConfig("message", e.target.value)}
                placeholder="Enter plugin message"
              />
            </div>
          </CardContent>
        </Card>

        {/* Testing Card */}
        <Card>
          <CardHeader>
            <CardTitle>Plugin Testing</CardTitle>
            <CardDescription>
              Test the plugin's API endpoints and functionality.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Button onClick={testPlugin} disabled={testing} variant="outline">
                {testing ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <TestTube className="h-4 w-4 mr-2" />
                )}
                Test Plugin
              </Button>

              <Button onClick={loadConfig} disabled={loading} variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Reload Config
              </Button>
            </div>

            {testResult && (
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">Test Result:</h4>
                <pre className="text-sm overflow-auto">
                  {JSON.stringify(testResult, null, 2)}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Plugin Info Card */}
        <Card>
          <CardHeader>
            <CardTitle>Plugin Information</CardTitle>
            <CardDescription>Details about the test plugin.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Plugin ID:</span>
                <span className="ml-2 text-muted-foreground">test-plugin</span>
              </div>
              <div>
                <span className="font-medium">Version:</span>
                <span className="ml-2 text-muted-foreground">1.0.0</span>
              </div>
              <div>
                <span className="font-medium">Category:</span>
                <span className="ml-2 text-muted-foreground">Utility</span>
              </div>
              <div>
                <span className="font-medium">Status:</span>
                <Badge variant={config.enabled ? "default" : "secondary"}>
                  {config.enabled ? "Enabled" : "Disabled"}
                </Badge>
              </div>
            </div>

            <div className="border-t pt-3">
              <span className="font-medium">API Endpoints:</span>
              <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                <li>• GET /api/plugin-routes/test/hello</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button onClick={saveConfig} disabled={saving} size="lg">
          {saving && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
          <Save className="h-4 w-4 mr-2" />
          Save Configuration
        </Button>
      </div>
    </div>
  );
};

export default TestSettings;
